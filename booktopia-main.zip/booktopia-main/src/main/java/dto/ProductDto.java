package dto;

public class ProductDto {
    
}
