package dto;

public class AdminDto {
    
}
