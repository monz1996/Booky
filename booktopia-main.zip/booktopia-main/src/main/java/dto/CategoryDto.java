package dto;

public class CategoryDto {
    
}
