package utils;

public class Result {
    // result that will be sent to the client and 
}
